/* Basically, I'm thinking of using JS to measure the height of each col div as it spawns, 
then using JS to reset the height of the col's parents to match if the col is too tall.*/
